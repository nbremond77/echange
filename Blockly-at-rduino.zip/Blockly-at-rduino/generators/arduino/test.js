goog.provide('Blockly.Arduino.test');
goog.require('Blockly.Arduino');

Blockly.Arduino.test_led = function() {
var dropdown_pin = Blockly.Arduino.valueToCode(this, 'NUM', Blockly.Arduino.ORDER_ATOMIC);
var dropdown_stat = this.getFieldValue('STAT');
Blockly.Arduino.setups_['setup_green_led_'+dropdown_pin] = 'pinMode('+dropdown_pin+', OUTPUT);'; var code = 'digitalWrite('+dropdown_pin+','+dropdown_stat+');\n'
return code;
};